import React, { Component } from 'react'
import Button from '@material-ui/core/Button';

export default class Ex1Button extends Component {
    render() {
        return (
            <div>
                <Button variant="contained"
                color= "primary">Bla Bla</Button>
                <Button variant="outlined"
                color= "primary">Bla Bla</Button>
                <Button variant="contained"
                color= "secondary">Bla Bla</Button>

            </div>
        )
    }
}
