import React, { Component } from 'react'
import Ex1Button from './Ex1Button';
export default class MyApp1 extends Component {
    render() {
        return (
            <div>
                <Ex1Button />
            </div>
        )
    }
}
