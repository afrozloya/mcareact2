import React, { Component } from 'react'
// import Myapp1 from './Myapp1';
// import Paperbase from './MyTheme/Paperbase'
import MyApp1 from './SimpleMatEx/MyApp1';

export default class App extends Component {
  render() {
    return (
      <div>
        <MyApp1 />        
      </div>
    )
  }
}
