var express = require("express");
var bodyParser = require("body-parser")
var movies = require("./movies")
var app = express();
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended:true}))
app.use("/movies", movies);
app.listen(3000)