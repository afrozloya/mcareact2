
var express = require("express");
var router = express.Router();

var movies = [
    {id: 101, name: "Fight Club", year: 1999, rating: 8.1},
    {id: 102, name: "Inception", year: 2010, rating: 8.7},
    {id: 103, name: "The Dark Knight", year: 2008, rating: 9},
    {id: 104, name: "12 Angry Men", year: 1957, rating: 8.9}
 ];

router.get("/", function(req, res){
    res.json(movies);
})
router.post("/", function(req, res){
    console.log(req.body);
    var m1 = req.body;
    movies.push(m1)
    res.json(m1);
})
router.get("/:id", function(req, res){
    console.log(req.params.id);
    var selMovie = movies.find(function(m1){
        if(m1.id==req.params.id){
            return true;
        } else {
            return false;
        }
    })
    res.json(selMovie);
})

router.delete("/:id", function(req, res){
    console.log(req.params.id);
    movies = movies.filter(function(m1){
        if(m1.id!=req.params.id){
            return true;
        } else {
            return false;
        }
    })
    res.json({message:"Deleted"});
})

router.put("/:id", function(req, res){    
    console.log(req.params.id);
    movies.forEach(m1 => {
        if(m1.id==req.body.id){
            m1.name=req.body.name;
            m1.year=req.body.year;
            m1.rating=req.body.rating;
        }
    });
    res.json({message:"Updated!"});
})



module.exports = router