var express = require('express');
var app = express();

app.get('/', function(req, res){
   var err = new Error("kuch to gadbad hai....");
   throw err;
   res.send("All Good!");
});

app.use(function(err, req, res, next) {
   res.status(500);
   res.send("Oops, something went wrong."+ err)
});

app.listen(3000);