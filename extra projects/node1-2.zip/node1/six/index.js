var url = require('url')
var myurl = "http://localhost:8080/default.htm?year=2017&month=february"
var q = url.parse(myurl, true)
console.log(q.host)
console.log(q.port)
console.log(q.protocol)
console.log(q.pathname)
console.log(q.search)
var qd = q.query
console.log(qd)
console.log(qd.year)
console.log(qd.month)






