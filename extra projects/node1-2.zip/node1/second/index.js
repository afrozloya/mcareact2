var http = require('http')
var dt = require('./mymodule')
http.createServer(function(req, res){
    res.writeHead(200, {"Content-Type":"text/html"});
    res.end("<h1> Date is " + dt.myDateFn() + "</h1>");
}).listen(8081)