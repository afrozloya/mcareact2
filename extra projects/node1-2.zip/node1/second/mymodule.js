exports.myDateFn = function() {
    return Date();
}