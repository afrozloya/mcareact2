var nodemailer = require('nodemailer')
var transpoter = nodemailer.createTransport({
    service:'gmail',
    auth: {
        'user':'ec.smtp.test2@gmail.com',
        'pass':'surajsahu123'
    }
})
var emailOp = {
    "from":"ec.smtp.test2@gmail.com",
    "to":"aloya.effcon@gmail.com",
    "subject":"hi from node!",
    // "text": "bla bla"
    "html": "<h1>hummmm....</h1>"
}
transpoter.sendMail(emailOp, function(err, info){
    if(err){
        console.log(err);
    }
    else{
        console.log("Done! :: " + info.response);
    }
})