var http = require("http")
var url = require("url")
var formidable = require("formidable")
var fs = require("fs")
http.createServer(function(req, res){
    var q = url.parse(req.url, true);
    if(q.pathname==="/uploadfile"){
        var form = new formidable.IncomingForm()
        form.parse(req, function(err,fields,files){
            fs.rename(files.at1.path, "C:\\Users\\com\\"+files.at1.name, function(err){
                console.log(err);
                res.writeHead(200, {"Content-Type":"text/html"});
                res.write("<h1>Done!!....</h1>");
                res.end();    
                })
        })
    } else {
        res.writeHead(200, {"Content-Type":"text/html"});
        res.write("<form action='uploadfile' method='post' enctype='multipart/form-data'>");
        res.write("<input name='at1' type='file' />");
        res.write("<button>Submit</<button>");
        res.write("</form>");
        res.end();    
    }
}).listen(8081)