var fs = require("fs")
var rs = fs.createReadStream("./nine/demofile.txt")
rs.on("open", function(){
    console.log("sab badiya!!")
})