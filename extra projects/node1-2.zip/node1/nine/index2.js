var events = require("events")
var ee = new events.EventEmitter()

ee.on("screem", function(){
    console.log("Kaun Bola!!!!")
})

console.log(1)
ee.emit("screem")
console.log(2)