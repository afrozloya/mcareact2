var mongoose = require('mongoose');
var Schema = mongoose.Schema;
var MovieSchema = new Schema({
    id: Number,
    name: {
      type: String,
      required: true
    },
    year:{
        type: Number,
        min: 1900, max: 2020,
        required: true
      },
      rating:{
        type: Number,
        min: 0, max: 10,
        required: true
      },

  });
//   MovieSchema.static('findByTitle', function(title) {
//     return this.find({ title: title });
//   });
  
var Movie = mongoose.model('Movie', MovieSchema );

module.exports = Movie