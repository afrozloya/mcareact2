var Movie = require("./moviesModel")
function getDb(){
    return new Promise((resolve, reject) => {
        var mongoose = require('mongoose');
        var mongoDB = 'mongodb://127.0.0.1/moviesdb';
        mongoose.connect(mongoDB, { useNewUrlParser: true,  useUnifiedTopology: true  });
        var db = mongoose.connection;
        db.on('error', (err)=>{
            reject(err)
        })
        db.once('open', function() {
            resolve(db);
        });        
    })    
}
function getMovies(){
    return new Promise((resolve, reject) => {
        getDb().then( dbo => {
            Movie.find({}, function(err, movies){
                if(err){
                    reject(err);
                } else {
                    resolve(movies);
                }
            })        
        })
    });
}            

function insertMovie(m1tmp){
    return new Promise((resolve, reject) => {
        getDb().then( dbo => {
            var m1 = new Movie({...m1tmp});
            m1.save(function(err){
                if(err){
                    reject(err);
                }
                else {
                    resolve({"message":"saved"});
                }
            })        
        })
    });
}     

function getMovieById(id){
    return new Promise((resolve, reject) => {
        getDb().then( dbo => {
            var query = {id: id} 
            Movie.find(query,function(err, res){
                if(err){
                    reject(err);
                } else {
                    resolve(res);
                }
            })
        })
    });
}            

function deleteMovie(id){
    return new Promise((resolve, reject) => {
        getDb().then( dbo => {
            var query = {id: +id} 
            Movie.deleteOne(query,function(err, res){
                if(err){
                    reject(err);
                } else {
                    resolve(res);
                }
            })
        })
    });
}            

function updateMovie(id, m1){
    return new Promise((resolve, reject) => {
        getDb().then( dbo => {
            var query = {id: +id} 
            var update = { $set: {...m1}}
            var options = { multi: true };
        
        Movie.update(query, update, options, function(err, res){
            if(err){
                reject(err);
            } else {
                resolve(res);
            }
        })
    });
 });
}            


module.exports = {
    getMovies,
    insertMovie,
    getMovieById,
    deleteMovie,
    updateMovie
}
