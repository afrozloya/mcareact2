var express = require("express");
var moviedb = require("./moviesdb");
var router = express.Router();
router.get("/", function(req, res){
    moviedb.getMovies().then(movies => {
        console.log(movies);
        res.json(movies);    
    })
})
router.post("/", function(req, res){
    var m1 = req.body;
    moviedb.insertMovie(m1).then(movies => {
        console.log(movies);
        res.json(movies);    
    })
})
router.get("/:id", function(req, res){
    moviedb.getMovieById(req.params.id).then(movies => {
        console.log(movies);
        res.json(movies);    
    })
})
router.delete("/:id", function(req, res){
    moviedb.deleteMovie(req.params.id).then(movies => {
        console.log(movies);
        res.json({message:"deleted"});    
    })
})
router.put("/:id", function(req, res){
    var m1 = req.body;
    moviedb.updateMovie(req.params.id, m1).then(movies => {
        console.log(movies);
        res.json(movies);    
    })
})


module.exports = router