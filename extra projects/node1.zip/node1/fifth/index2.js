var fs = require('fs')
fs.unlink("kuchbhi.txt", function (err){
    if(err){
        console.log("oops " + err)
    }
    else{
        console.log("deleted!")
    }
})