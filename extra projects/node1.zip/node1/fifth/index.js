var fs = require('fs')
fs.appendFile("kuchbhi.txt", "bla bla", function (err){
    if(err){
        console.log("oops " + err)
    }
    else{
        console.log("Done!")
    }
})