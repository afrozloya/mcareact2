var fs = require('fs')
fs.rename("kuchbhi.txt", "naya.txt", function (err){
    if(err){
        console.log("oops " + err)
    }
    else{
        console.log("done!")
    }
})