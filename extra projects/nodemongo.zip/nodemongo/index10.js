var MongoClient = require('mongodb').MongoClient
var url = "mongodb://localhost:27017/"
MongoClient.connect(url, function(err, db){
    if(err){
        throw err;
    } else {
        console.log("connected!")
        var dbo = db.db("mydb2");
        var sel = {name:/v/i}
        var up = {$set: {address: 'Rajnangaon'}}

        // dbo.collection("customers").updateOne(sel, up, 
        //         function(err, res){
        //     if(err) throw err;
        //     console.log(res);
        // })

        dbo.collection("customers").updateMany(sel, up, 
                function(err, res){
            if(err) throw err;
            console.log(res);
        })

        dbo.collection("customers").find(sel).toArray(function(err, res){
            if(err) throw err;
            console.log(res);
        })
    }
})