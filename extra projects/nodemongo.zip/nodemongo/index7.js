var MongoClient = require("mongodb").MongoClient;
var url = "mongodb://localhost:27017/mydb2";
MongoClient.connect(url, function(err, db){
    if(err){
        console.log(err);
        throw err;
    } else {
        var dbo = db.db("mydb2");
        // var query = {name: 'John'}
        // var query = {name: /a/i}
        var query = {name: /V/i}
        var sortby = {name:-1}
        dbo.collection("customers").find(query, {'projection':{'_id':0 }}).sort(sortby).toArray(function(err, res){
            if(err){
                console.log(err);
                throw err;
            } else {
                console.log(res);
            }        
        })
    }
})
