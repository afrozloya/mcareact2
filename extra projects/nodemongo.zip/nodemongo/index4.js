// var mongo = require("mongodb");
var MongoClient = require("mongodb").MongoClient
var url = "mongodb://localhost:27017";
MongoClient.connect(url, function(err, db){
    if(err){
        console.log(err);
        throw err;
    } else {
        var dbo = db.db("mydb2");
        dbo.collection("customers").findOne({}, function(err, res){
            if(err){
                console.log(err);
                throw err;
            } else {
                console.log(res);
            }
        })
    }
})
