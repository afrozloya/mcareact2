// var mongo = require("mongodb");
var MongoClient = require("mongodb").MongoClient
var url = "mongodb://localhost:27017/mydb2";
MongoClient.connect(url, function(err, res){
    if(err){
        console.log(err);
        throw err;
    } else {
        console.log("connected!");
        
    }
})
