// var mongo = require("mongodb");
var MongoClient = require("mongodb").MongoClient
var url = "mongodb://localhost:27017";
MongoClient.connect(url, function(err, db){
    if(err){
        console.log(err);
        throw err;
    } else {
        var dbo = db.db("mydb2");


        var data = [
            { _id: 1, product_id: 154, status: 1 }
        ];
          dbo.collection("orders").insertMany(data, function(err, res){
              if(err){
                  console.log(err);
                  throw err;
              }
              else {
                  console.log("inserted!");
              }
          })


          var data = [
            { _id: 154, name: 'Chocolate Heaven' },
            { _id: 155, name: 'Tasty Lemons' },
            { _id: 156, name: 'Vanilla Dreams' }              
        ];
          dbo.collection("products").insertMany(data, function(err, res){
              if(err){
                  console.log(err);
                  throw err;
              }
              else {
                  console.log("inserted!");
              }
          })


    }
})
