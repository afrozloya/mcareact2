var MongoClient = require("mongodb").MongoClient;
var url = "mongodb://localhost:27017/mydb2";
MongoClient.connect(url, function(err, db){
    if(err){
        console.log(err);
        throw err;
    } else {
        var dbo = db.db("mydb2");
        dbo.collection("customers").find({}, {'projection':{'_id':0, name:0 }}).toArray(function(err, res){
            if(err){
                console.log(err);
                throw err;
            } else {
                console.log(res);
            }        
        })
    }
})
