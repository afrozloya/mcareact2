export const ADD_TODO = "ADD_TODO"
export const DEL_TODO = "DEL_TODO"
export const UP_TODO = "UP_TODO"

