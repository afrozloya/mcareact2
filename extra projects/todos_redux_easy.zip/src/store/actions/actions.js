import * as actionTypes from './actionTypes'
let id = 1;
export const addTodo = (text) => {
    return {
        type: actionTypes.ADD_TODO,
        text: text,
        id: id++
    }
}

export const delTodo = (localId) => {
    return {
        type: actionTypes.DEL_TODO,
        id: localId
    }
}


export const upTodo = (localId, text) => {
    return {
        type: actionTypes.UP_TODO,
        text: text,
        id: localId
    }
}
