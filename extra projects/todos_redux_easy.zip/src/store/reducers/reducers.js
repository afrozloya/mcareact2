import * as actionTypes from '../actions/actionTypes'

const initState = {
    todos: []
}

const addTodo = (state, action) => {
    let newTodos = [...state.todos];
    newTodos.push({id: action.id, text: action.text})
    return {
        ...state,
        todos: newTodos
    }
}

const delTodo = (state, action) => {
    let newTodos = state.todos.filter(t1 => {return t1.id !== action.id})
    return {
        ...state,
        todos: newTodos
    }
}

const upTodo = (state, action) => {
    const newTodos = [];
    state.todos.forEach(t1 => {
        if(t1.id === action.id){
            t1.text = action.text;
        }
        newTodos.push(t1)
    });
    return {
        ...state,
        todos: newTodos
    }
}


const reducers = (state=initState, action) => {
    switch(action.type){
        case actionTypes.ADD_TODO:
            return addTodo(state, action);
        case actionTypes.DEL_TODO:
            return delTodo(state, action);
        case actionTypes.UP_TODO:
            return upTodo(state, action);
        default:
            return state;
    }
}

export default reducers;