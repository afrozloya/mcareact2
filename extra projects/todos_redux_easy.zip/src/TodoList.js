import React, { Component } from 'react'
import {connect} from 'react-redux'
import {delTodo, upTodo} from './store/actions/actions'
class TodoList extends Component {

    onDelHand = (id) => {
        this.props.delTodo(id);
    }
    onUpHand = (id) => {
        this.props.upTodo(id, this.state.text);
    }

    state = {
        si: '',
        text: ''
    }

    onChHand = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }

    render() {

        const dispTodos = this.props.todos.filter(t1 => {
            const sir = new RegExp(this.state.si, "i");
            return t1.text.search(sir)!=-1;
        })

        return (
            <div>
                <input name="text"
                placeholder="New Text"
                value={this.state.text}
                onChange={this.onChHand}
                /><br/>
                <input name="si"
                value={this.state.si}
                onChange={this.onChHand}
                />
                {dispTodos.map(t1 => <h1 key={t1.id}>{t1.text}
                <button onClick={()=>{this.onDelHand(t1.id)}}>X</button>
                <button onClick={()=>{this.onUpHand(t1.id)}}>Update</button>
                </h1>)}
            </div>
        )
    }
}
const mapStateToProps = state => {
    return {
        todos: state.todos
    }
}
const mapDispatchToProps = dispatch => {
    return {
        delTodo: (id) => {dispatch(delTodo(id))}, 
        upTodo: (id, text) => {dispatch(upTodo(id, text))}
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(TodoList)
