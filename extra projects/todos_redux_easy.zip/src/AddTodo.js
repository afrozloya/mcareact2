import React, { Component } from 'react'
import {connect} from 'react-redux'
import {addTodo} from './store/actions/actions'
class AddTodo extends Component {
    state = {
        text: ''
    }
    onChHand = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }
    onClkHand = (e) => {
        this.props.addTodo(this.state.text);
        this.setState({
            text: ''  
        })
    }
    render() {
        return (
            <div>
                <h1>Add Todo</h1>
                <input placeholder="Todo" name="text"
                value={this.state.text}
                onChange={this.onChHand}
                />
                <button onClick={this.onClkHand}>Add</button>
            </div>
        )
    }
}
const mapDispatchToProps = dispatch => {
    return {
        addTodo: (text) => {dispatch(addTodo(text))} 
    }
}
export default connect(null, mapDispatchToProps)(AddTodo)
