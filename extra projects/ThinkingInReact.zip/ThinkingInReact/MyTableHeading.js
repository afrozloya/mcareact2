import React from 'react'

export default function MyTableHeading(props) {
    return (
            <tr><th colSpan="2">{props.ocate}</th></tr>
    )
}
