import React, {Fragment} from 'react'
import MyTableRow from './MyTableRow'
import MyTableHeading from './MyTableHeading'

export default function MyTable(props) {
    let ocate = '';
    return (
        <table>
        <thead>
        <tr><th>Name</th><th>Price</th></tr>                    
        </thead>
        <tbody>
    {
        props.filteredData.map(                        
            e => {
                let showCate = false;
                if(ocate !== e.category){
                    ocate = e.category;
                    showCate = true;
                }
                return <Fragment key={e.name}>
                   { showCate && <MyTableHeading ocate={ocate}/> }
                   <MyTableRow e={e} />
                </Fragment>
            }
        )
    }
    
    </tbody>
    </table>
)
}
