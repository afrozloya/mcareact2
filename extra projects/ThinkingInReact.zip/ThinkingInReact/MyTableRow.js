import React from 'react'

export default function MyTableRow(props) {
    return (
        <tr>
        {
            props.e.stocked
            ? <td>{props.e.name}</td>
            : <td style={{color:'red'}}>{props.e.name}</td>
        }
        <td>{props.e.price}</td>
        </tr>
    )
}
