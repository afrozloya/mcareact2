import React, { Component, Fragment } from 'react'
import MyTable from './MyTable'
import SearchControles from './SearchControles'
import {data} from './data'
export default class MyApp extends Component {   
    state= {
        si: '',
        stocked_only: false
    }      
    onChangeHand = (e) => {
        if(e.target.type==="checkbox"){
            this.setState({
                [e.target.name]: e.target.checked
            })    
        } else {
            this.setState({
                [e.target.name]: e.target.value
            })    
        }
    }

    render() {
        const filteredData = data.filter(
            e => {
                var r1 = new RegExp(this.state.si, "i")
                if(e.name.search(r1)!==-1){
                    if(this.state.stocked_only){
                        return e.stocked;
                    }else{
                        return true;
                    }
                }
                else {
                    return false;
                }
            }
        )
        return (
            <div>
                <h1>Items!!</h1>
                <SearchControles si={this.state.si} stocked_only={this.state.stocked_only}
                onChangeHand = {this.onChangeHand}
                />
                <MyTable filteredData={filteredData} />
            </div>
        )
    }
}
