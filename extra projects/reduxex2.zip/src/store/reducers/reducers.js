import * as actionTypes from '../actions/actionTypes'

const initState = {
    no: 0
}

const incr = (state, action) => {
    return {
        ...state,
        no: state.no + action.by
    }
}

const decr = (state, action) => {
    return {
        ...state,
        no: state.no - action.by
    }
}

const reducer = (state=initState, action) => {
    switch(action.type){
        case actionTypes.INCR:
            return incr(state, action);
        case actionTypes.DECR:
            return decr(state, action);
        default:
            return state;
    }
}

export default reducer;