import {createStore, compose} from 'redux'
import myreducer from './reducers/reducers'
const enhComp = window.__REDUX_DEVTOOLS_EXTENSION_COMPOSE__ || compose
const store = createStore(myreducer, enhComp())
export default store;
