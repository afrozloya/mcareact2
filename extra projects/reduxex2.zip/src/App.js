import React, { Component } from 'react'
import { connect } from 'react-redux';
import {incr, decr} from './store/actions/actions'

class App extends Component {
  render() {
    return (
      <div>        
        <h1>
        <button onClick={()=>{this.props.mydecr()}}>-</button>
        {this.props.no}
        <button onClick={()=>{this.props.myincr()}}>+</button>
        </h1>
      </div>
    )
  }
}
const mapStateToProps = state => {
  return {
    no: state.no
  }
}
const mapDispatchToProps = dispatch => {
  return {
    myincr: () => {dispatch(incr())},
    mydecr: () => {dispatch(decr())}  
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(App)
