import React, { Component, createContext } from 'react'
import B from './B'
import MyCtx from './MyCtx'


export default class index extends Component {
    state = {
        name: 'samjhe kya....'
    }
    onClk = () => {
        this.setState({
            name: 'naya',
        })
    }
    render() {
        return (
            <div>
                <MyCtx.Provider value={this.state}>
                <h1>kake.....</h1>
                <button onClick={this.onClk}>Clk me</button>
                <B />
                </MyCtx.Provider>
            </div>
        )
    }
}
