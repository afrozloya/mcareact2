import React from 'react'
const MyCtx = React.createContext({name:'kk'})
export default MyCtx