import React from 'react'

function A2(props, ref) {
    return (
        <div>
            <input ref={ref} />           
        </div>
    )
}

export default React.forwardRef(A2)