import React, { Component } from 'react'
import A from './A'
// import A from './A2'
export default class index extends Component {
    myref = React.createRef(null);
    onClkHand = () => {
        this.myref.current.focus();
    }
    render() {
        return (
            <div>
                <h1>My Ref.....</h1>
                <A ref={this.myref}/>
                <button onClick={this.onClkHand}>Clk Me</button>
            </div>
        )
    }
}
