import React, { Component } from 'react'
import Faltu2 from './Faltu2'
import Faltu from './Faltu'
export default class componentName extends Component {
    render() {
        return (
            <div>
                <Faltu2 />
                <Faltu />
            </div>
        )
    }
}
