import React, { Component } from 'react'
import Clock from './Clock'

export default class App3 extends Component {
    render() {
        return (
            <div>
                <Clock />
            </div>
        )
    }
}
