import React from 'react'
import * as classes from './Car.module.css'
export default function Car(props) {
    return (
        <div className={classes.box}>
                <h1>I am a {props.brand} car!!</h1>
                <p>My color is {props.color}</p>
                <p>I was born in {props.make}</p>
        </div>
    )
}
