import React, { Component } from 'react'
import Sum from './Sum'

export default class A extends Component {
    state = {
        no1: 0,
        no2: 0,
        no3: 0
    }
    onChangHand = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }
    render() {
        return (
            <div>
                <input name="no1" value={this.state.no1} onChange={this.onChangHand} />
                <input name="no2" value={this.state.no2} onChange={this.onChangHand} />
                <input name="no3" value={this.state.no3} onChange={this.onChangHand} />
                <Sum no1={this.state.no1} no2={this.state.no2} />
            </div>
        )
    }
}
