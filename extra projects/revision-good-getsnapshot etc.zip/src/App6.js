import React, { Component } from 'react'
import ScrollingList from './ScrollingList'
export default class App6 extends Component {
    render() {
        return (
            <div>
                <ScrollingList />
            </div>
        )
    }
}
