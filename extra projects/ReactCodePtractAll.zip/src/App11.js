import React, { Component } from 'react'

export default class App11 extends Component {
    state={
        value:["grapefruit", "coconut"]
    }
    handleChange = (e) => {
        let newVal = this.state.value;
        console.log(newVal)
        if(newVal.includes(e.target.value)){
            newVal = newVal.filter(ele => ele !== e.target.value)
        }else{
            newVal.push(e.target.value)
        }
        this.setState({value: newVal});
    }
    render() {
        return (
            <div>
            <select onChange={this.handleChange} multiple={true} value={this.state.value}>
            <option value="grapefruit">Grapefruit</option>
            <option value="lime">Lime</option>
            <option value="coconut">Coconut</option>
            <option value="mango">Mango</option>
          </select>
            </div>
        )
    }
}
