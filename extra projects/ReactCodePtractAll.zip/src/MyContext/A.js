import React, { Component } from 'react'
import MyCtx from './MyCtx'


export default class A extends Component {
    static contextType = MyCtx;
    render() {
        return (
            <div>
                <h1>Name is {this.context.name}</h1>
            </div>
        )
    }
}
