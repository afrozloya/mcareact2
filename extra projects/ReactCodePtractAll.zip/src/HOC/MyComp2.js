import React from 'react'

export default function MyComp2() {
    return (
        <div>
            <p>bla bla bla bla bla</p>
        </div>
    )
}
