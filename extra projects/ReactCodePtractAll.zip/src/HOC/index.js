import React, { Component } from 'react'
import MyComp from './MyComp'
import MyComp2 from './MyComp2'
import myhoc from './myhoc'
import FancyBorder from './FancyBorder'

export default class componentName extends Component {
    render() {
        const MyComp2Mod = myhoc(MyComp2) 
        return (
            <FancyBorder>
                <h1>HOC...</h1>
                <MyComp />
                <MyComp2Mod />
            </FancyBorder>
        )
    }
}
