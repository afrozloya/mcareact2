import React from 'react'
import myhoc from './myhoc'

function MyComp() {
    return (
        <div>
            <h1>Bla bla</h1>
        </div>
    )
}
export default myhoc(MyComp)
