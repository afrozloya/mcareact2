import React from 'react'

export default function myhoc(OrigComp) {
    return () => {
        return (
            <div style={{border: '1px solid red'}}>
                <OrigComp />
            </div>
        )
    } 
}
