import React from 'react'

export default function FancyBorder(props) {
    return (
        <div style={{border: '1px solid blue'}}>
            {props.children}
        </div>
    )
}
