import React from 'react'
import {render, unmountComponentAtNode} from 'react-dom'
import {act} from 'react-dom/test-utils'
import Hello from './Hello'
let container = null;
beforeEach(()=>{
    //setup
    console.log("++++++++++++++++++++++++++++++++++++++++")
    container = document.createElement("div");
    document.body.appendChild(container);
})
afterEach(()=>{
    //teardown
    console.log("------------------------------------------")
    unmountComponentAtNode(container);
    container.remove();
    container = null;
})
it("render hello with or without name", ()=>{
    act(()=>{
        render(<Hello />, container);
    })
    expect(container.textContent).toBe("Hey, stranger");
    act(()=>{
        render(<Hello name="Afroz" />, container );
    })
    expect(container.textContent).toBe("Hello, Afroz!");
    act(()=>{
        render(<Hello name="kk" />, container);
    })
    expect(container.textContent).toBe("Hello, kk!");
})