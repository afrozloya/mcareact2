import React from 'react'
import Hello from './Hello'

export default function index() {
    return (
        <div>
            <h1>bla bla</h1>
            <Hello name="kk"/>
        </div>
    )
}
