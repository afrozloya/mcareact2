import React, { Component } from 'react'

export default class App10 extends Component {
    state = {
        isLogin: true
    }
    render() {
        return (
            <div>
                <h1>Dikha Kya ?? {this.state.isLogin ? 'Yes' : 'No'}</h1>                
            </div>
        )
    }
}
