import React, { Component } from 'react'

export default class TempInput extends Component {
    render() {
        return (
            <div>
                <input name="temp" value={this.props.temp} onChange={this.props.myOnChange}/>
            </div>
        )
    }
}
