import React, { Component } from 'react'

class A extends Component {
    render() {
        return (
            <div>
            <input ref={this.props.forwordedRef} />
            </div>
        )
    }
}
export default React.forwardRef((props, ref) => {
    return <A forwordedRef={ref}  {...props}/>
})
