import React, { Component } from 'react'
import './FancyBorder.css'
export default class FancyBorder extends Component {
    render() {
        return (
            <div className="text-effect">
        <h1 className="neon" data-text={this.props.children}>{this.props.children}</h1>
        <div className="gradient"></div>
        <div className="spotlight"></div>
        </div>
        )
    }
}
