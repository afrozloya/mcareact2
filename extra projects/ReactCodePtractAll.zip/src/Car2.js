import React, { Component } from 'react'

export default class Car2 extends Component {
    state = {
        brand: this.props.brand,
        obrand: this.props.brand
    }
    static getDerivedStateFromProps(nextProps, prevState) {
        if(prevState.obrand !== nextProps.brand){
            return {            
                brand: nextProps.brand,
                obrand: nextProps.brand
            }    
        }
        else {
            return null
        }
    }
    onChangHand = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }
    render() {
        return (
            <div>
                <p>{this.state.brand}</p>
                <input name="brand" value={this.state.brand} onChange={this.onChangHand} />
            </div>
        )
    }
}
