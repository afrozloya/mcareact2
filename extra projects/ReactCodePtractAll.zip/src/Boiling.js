import React, { Component } from 'react'

export default class Boiling extends Component {
    render() {
        return (
            <div>
                <h1>
                {
                    this.props.temp>=100
                    ? 'It will boil'
                    : 'Nope!!'
                }
                </h1>
            </div>
        )
    }
}
