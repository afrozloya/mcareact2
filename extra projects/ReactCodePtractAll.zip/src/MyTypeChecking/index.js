import React, { Component } from 'react'
import MyComp from './MyComp'
export default class index extends Component {
    render() {
        return (
            <div>
                <MyComp age="abc" />
            </div>
        )
    }
}
