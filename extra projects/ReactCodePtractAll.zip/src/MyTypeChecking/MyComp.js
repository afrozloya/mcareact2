import React, { Component } from 'react'
import PropTypes from 'prop-types'

export default class MyComp extends Component {
    static propTypes = {
        age: PropTypes.number
    }
    render() {
        return (
            <div>
                <h1>next yr your age will be {+this.props.age+1}</h1>
            </div>
        )
    }
}
// MyComp.propTypes = {
//     age: PropTypes.number
// }