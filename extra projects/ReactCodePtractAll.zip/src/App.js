import React, { Component } from 'react'
import Car from './Car'

export default class App extends Component {
  state = {
    show: true,
    cars: [
      {"brand":"BMW", "color":"Red", "make":"2020", "id": 1},
      {"brand":"Nano", "color":"Blue", "make":"2019", "id": 2},
      {"brand":"Merc", "color":"Black", "make":"2010", "id": 3},
      {"brand":"Maruti", "color":"White", "make":"2000", "id": 4},
    ],
    brand: "Lotus"
  }
  onChangeHand = (e) => {
    this.setState({
      [e.target.name]: e.target.value
    })
  }
  render(){
    return (
      <div>
        <button onClick={()=>{this.setState({show:false})}}>Hide</button>
        <h1>Samjhe</h1>
        <input 
        name="brand" 
        value={this.state.brand}
        onChange={this.onChangeHand}
        />
        { this.state.cars.map( car => <Car key={car.id} {...car} /> ) }
         {
           this.state.show
           ? <Car brand={this.state.brand} />
           : null
         }
         
      </div>
    )    
  }
}
