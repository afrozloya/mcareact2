import React, { Component } from 'react'

export default class MyErr extends Component {
    render() {
        // throw 'my error'
        return (
            <div>
                <h1>okok</h1>
            </div>
        )
    }
}
