import React, { Component } from 'react'

export default class App12 extends Component {
    state = {
        agree: false
    }
    onCh = (e) => {
        this.setState({
            [e.target.name]: e.target.checked
        })
    }
    render() {
        return (
            <div>
                <h1>
                {
                    this.state.agree
                    ? 'You have agrred'
                    : 'Nahi hai to ja....'
                }
                </h1>
                <label>
                    I Agree 
                <input name="agree" type="checkbox" checked={this.state.agree} 
                onChange={this.onCh}
                />
                </label>
            </div>
        )
    }
}
