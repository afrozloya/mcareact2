import React, { Component } from 'react'
import Car2 from './Car2'

export default class Parent extends Component {
    state = {
        brand: "bmw"
    }
    onChangHand = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }
    render() {
        return (
            <div>
                <h1>{this.state.brand}</h1>
                <select name="brand" value={this.state.brand} onChange={this.onChangHand}>
                <option value="bmw">BMW</option>
                <option value="merc">Merc</option>
                <option value="maruti">Maruti</option>
                </select>
                <Car2 brand={this.state.brand} />
            </div>
        )
    }
}
