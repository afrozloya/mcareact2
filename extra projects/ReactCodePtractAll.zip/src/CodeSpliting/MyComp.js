import React from 'react'
// import {add} from './math'
export default function MyComp() {
    // const m1 = () => {
    //     let res = add(2,3);
    //     console.log(res);
    // }
    const m1 = () => {
        import('./math').then(math=>{
            let res = math.add(2,3);
            console.log(res);
        })
    }
    return (
        <div>
            <button onClick={m1}>Clk Me</button>
        </div>
    )
}
