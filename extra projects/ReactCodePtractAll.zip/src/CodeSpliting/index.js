import React from 'react'
import MyComp from './MyComp'
export default function index() {
    return (
        <div>
            <h1>Code Splitting....</h1>
            <MyComp/> 
        </div>
    )
}
