import React, { useState } from 'react'
import useInputValue from './useInputValue';

export default function Index() {
    const uname = useInputValue('Saroj')
    const age = useInputValue(21)
    return (
        <div>
            <h1>{uname.value} :: {age.value}</h1>
            <input {...uname} />
            <input {...age}/>
        </div>
    )
}
