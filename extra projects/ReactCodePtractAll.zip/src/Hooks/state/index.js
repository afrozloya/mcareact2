import React, {useState} from 'react'

export default function Index() {
    const [uname, setUname] = useState("bla")
    return (
        <div>
            <h1>Hooks</h1>
            <input value={uname} onChange={(e)=>{setUname(e.target.value)}} />
        </div>
    )
}
