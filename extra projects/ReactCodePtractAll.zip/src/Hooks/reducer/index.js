import React, {useReducer} from 'react'

export default function Index() {
    const reducer = (state, action) => {
        switch(action.type){
            case 'incr':
                return {...state, count: state.count+1}
            case 'decr':
                return {...state, count: state.count-action.no}
            default:
                return state;
        }
    }    
    const initialState = {count: 0}
    const [state, dispatch] = useReducer(reducer, initialState)
    return (
        <div>
            <h1>Reducer!</h1>
            <h1>{state.count}</h1>
            <button onClick={()=>{dispatch({type:'incr'})}}>+</button>
            <button onClick={()=>{dispatch({type:'decr', no:2})}}>-</button>
        </div>
    )
}
