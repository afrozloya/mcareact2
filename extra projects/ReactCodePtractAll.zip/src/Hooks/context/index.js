import React, { useState } from 'react'
import A from './A'
import {MyCtx} from './MyCtx'
export default function Index() {
    const [uname, setuname] = useState('')
    return (
        <MyCtx.Provider value={{uname: uname}}>
            <input value={uname} onChange={(e)=>{setuname(e.target.value)}} />
            <A uname={uname} />
        </MyCtx.Provider>
    )
}
