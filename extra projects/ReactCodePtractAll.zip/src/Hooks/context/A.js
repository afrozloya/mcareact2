import React from 'react'
import B from './B'
export default function A(props) {
    return (
        <div>
            <B uname={props.uname} />
        </div>
    )
}
