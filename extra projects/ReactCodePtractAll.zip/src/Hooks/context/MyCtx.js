import React from 'react'
let initCtx = {
    uname: 'blabla'
} 
export const MyCtx = React.createContext(initCtx)
