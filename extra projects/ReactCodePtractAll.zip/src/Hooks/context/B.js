import React, {useContext} from 'react'
import {MyCtx} from './MyCtx'
export default function B() {
    const context = useContext(MyCtx)
    return (
        <div>
            <h1>{context.uname}</h1>
        </div>
    )
}
