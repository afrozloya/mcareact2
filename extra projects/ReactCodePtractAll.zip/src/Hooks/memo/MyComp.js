import React from 'react'

function MyComp(props) {
    console.log("MyComp called.........")
    return (
        <div>
            <p>Sum is {+props.a + +props.b}</p>
        </div>
    )
}
export default React.memo(MyComp)
