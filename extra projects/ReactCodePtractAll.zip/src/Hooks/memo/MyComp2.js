import React from 'react'

function MyComp2(props) {
    console.log("MyComp2***************************")
    return (
        <div>
            <p>Sum is {+props.a + +props.b}</p>
        </div>
    )
}
export default React.memo(MyComp2)
