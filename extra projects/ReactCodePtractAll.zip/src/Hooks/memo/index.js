import React, { useState, useMemo, useCallback } from 'react'
import MyComp from './MyComp'
import MyComp2 from './MyComp2'

export default function Index() {
    const [a, seta] = useState(0)
    const [b, setb] = useState(0)
    const [c, setc] = useState(0)    
    let res = useMemo(() => {return add(a,b)}, [a, b])
    const onClk = useCallback(
        () => {
            console.log("kake")
        }, []
    )
    return (
        <div>
            <h1>sum is {res}</h1>
            <input value={a} onChange={(e)=>{seta(e.target.value)}} />
            <input value={b} onChange={(e)=>{setb(e.target.value)}} />
            <input value={c} onChange={(e)=>{setc(e.target.value)}} />
            <hr />
            <MyComp a={a} b={b} />
            <hr />
            <MyComp2 clk={onClk} a={a} b={b} />
        </div>
    )
}
const add = (a, b) => {
    console.log("add called!!")
    return +a + +b;
}
