import React, {useState} from 'react'
import MyComp from './MyComp'
export default function Index() {
    const [count, setcount] = useState(0)
    const [count2, setcount2] = useState(0)
    return (
        <div>
            <h1>effect....</h1>
            {
                count<5
                ? <MyComp count={count}/>
                : null
            }
            
            <button onClick={()=>{setcount(count+1)}}>+</button>
            <button onClick={()=>{setcount2(count2+1)}}>+</button>
        </div>
    )
}
