import React, {useEffect} from 'react'

export default function MyComp(props) {
    useEffect(()=>{
        console.log("useEffect")
        return () => {
            console.log("Ram Naam Satya Hai!");
        }
    }, [])
    useEffect(()=>{
        console.log("useEffect ........ 2 ")
    })
    useEffect(()=>{
        console.log("useEffect ********* 3 ")
    }, [props.count])
    return (
        <div>
            <h1>MyComp {props.count}</h1>
        </div>
    )
}
