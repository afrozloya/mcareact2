import React from 'react'

export default function SearchControles(props) {
    return (
        <>
        <input name="si" value={props.si} onChange={props.onChangeHand} placeholder="Search" />
        <div>
            Show Stocked Only
        <input type="checkbox" name="stocked_only" checked={props.stocked_only} onChange={props.onChangeHand}/>
        </div>
        </>
)
}
