import React, { Component } from 'react'
import './Faltu.css'
import './Faltu.scss'
import mystyle from './Faltu.module.css' 


export default class componentName extends Component {
    state = {
        name: 'Afroz',
        age: 0,
        comment:'',
        car: 'fiat',
        error: null
    }
    onSub = (e) => {
        e.preventDefault();
        console.log(e)
    }
    onChHand = (e) => {
        let name = e.target.name
        let val = e.target.value
        let err = null;
        if(name==='age'){
            if(!Number(val)){
                // alert('no de.....');
                err = "No De....";
            }
        }
        this.setState({
            [name]:val,
            "error": err
        })

    }
    render() {
        const myst = {
            "backgroundColor":"#ffdddd",
            "padding": "20px",
            "border": "solid red 1px",
            "borderRadius": "20px"
        }
        return (
            <form onSubmit={this.onSub}>            
            <p style={myst}>{this.state.name} {this.state.car}</p>
            <h1 className="kk">bla bla</h1>
            <h1 className="kk3">bla Scss bla</h1>
            <h1 className={mystyle.kk2}>ok ok </h1>
            <input 
            name="name"
            value={this.state.name}
            onChange={this.onChHand}
            />
            <input 
            name="age"
            value={this.state.age}
            onChange={this.onChHand}
            />
            <textarea 
            rows="3"
            cols="40"
            name="acommentge"
            value={this.state.comment}
            onChange={this.onChHand}
            />

            <select name="car" value={this.state.car} onChange={this.onChHand}>
            <option value="ford">Ford</option>
            <option value="volvo">Volvo</option>
            <option value="fiat">Fiat</option>
            </select>
            
            <p style={{color: 'red'}}>{this.state.error}</p>
            <button>Abcd</button>
            </form>
        )
    }
}
