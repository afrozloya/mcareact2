var mongoose = require('mongoose');
var mongoDB = 'mongodb://127.0.0.1/mydb4';
var Movie = require("./movies")
mongoose.connect(mongoDB, { useNewUrlParser: true,  useUnifiedTopology: true  });
var db = mongoose.connection;
db.on('error', (err)=>{
    console.log("\n\n\nErrorwa\n\n\n", err)
})
db.once('open', function() {
    var conditions = { title: 'Dar' }
    // , update = { $inc: { visits: 1 }}
    var update = { $set: { category: "SciFi" }}
    var options = { multi: true };

Movie.update(conditions, update, options, function(err){
    if(err){
        console.log(err);
    } else {
        console.log("Done!!!");
    }
});
});