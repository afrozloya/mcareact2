var mongoose = require('mongoose');
var mongoDB = 'mongodb://127.0.0.1/mydb4';
var Movie = require("./movies")
mongoose.connect(mongoDB, { useNewUrlParser: true,  useUnifiedTopology: true  });
var db = mongoose.connection;
db.on('error', (err)=>{
    console.log("\n\n\nErrorwa\n\n\n", err)
})
db.once('open', function() {
    var query = Movie.findByTitle("Dar");
    query.exec(function (err, movies) {
    if (err) {
        console.log(err);
    } else {
        console.log(movies);
    }
    })
});