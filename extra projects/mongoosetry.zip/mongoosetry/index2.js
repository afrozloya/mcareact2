var mongoose = require('mongoose');
var mongoDB = 'mongodb://127.0.0.1/mydb4';
var Movie = require("./movies")
mongoose.connect(mongoDB, { useNewUrlParser: true,  useUnifiedTopology: true  });
var db = mongoose.connection;
db.on('error', (err)=>{
    console.log("\n\n\nErrorwa\n\n\n", err)
})
db.once('open', function() {
    Movie.find({title:/Dar/i}, function(err, movies){
        if(err){
            console.log("/n/n//nError::", err);
        } else {
            console.log(movies);
        }
    })
});