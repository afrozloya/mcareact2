var mongoose = require('mongoose');
var mongoDB = 'mongodb://127.0.0.1/mydb4';
var Movie = require("./movies")
mongoose.connect(mongoDB, { useNewUrlParser: true,  useUnifiedTopology: true  });
var db = mongoose.connection;
db.on('error', (err)=>{
    console.log("\n\n\nErrorwa\n\n\n", err)
})
db.once('open', function() {
    Movie.find({title:/Aaj/i}, function(err, movies){
        if(err){
            console.log("/n/n//nError::", err);
        } else {
            movies[0].category="Horor";
            movies[0].save();
            console.log(movies);
        }
    })
});