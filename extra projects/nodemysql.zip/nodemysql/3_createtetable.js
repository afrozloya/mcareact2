var mysql = require("mysql")
var con = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database: "mynodedb"
});
con.connect(function(err){
    if(err){
        console.log(err);
        return err;
    }
    console.log("conected!");
    var sql = "create table customers (id int auto_increment primary key, name varchar(255), address varchar(255)) ";
    con.query(sql, function(err, res){
        if(err){
            console.log(err);
            return err;
        }
        else {
            console.log("Done creating table!!")
        }
    })
})