var mysql = require("mysql")
var con = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database: "mynodedb"
});
con.connect(function(err){
    if(err){
        console.log(err);
        return err;
    }
    console.log("conected!");
    var sql = `select * from  customers order by name DESC`;
    con.query(sql, function(err, res, fields){
        if(err){
            console.log(err);
            return err;
        }
        else {
            console.log(res);
        }
    })
})