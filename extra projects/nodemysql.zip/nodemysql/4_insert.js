var mysql = require("mysql")
var con = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database: "mynodedb"
});
con.connect(function(err){
    if(err){
        console.log(err);
        return err;
    }
    console.log("conected!");
    var sql = "insert into customers (name, address) values ? ";
    var values = [
        ["Ajay", "Lapata"],
        ["Saroj", "Gumshuda"],
        ["Jagrity", "Missing"],
        ["Deepak", "JAl rah hai"],
        ["Shubhangi", "Shadi ka photos"],
        ["rishita", "working girl"],
        ["lipsa", "bla bla"],
        ["Anirban", "is he coming??"],
        ["Ravi", "Ragging...."],
        ["ritika", "Ragging...."],
    ]
    con.query(sql, [values], function(err, res){
        if(err){
            console.log(err);
            return err;
        }
        else {
            console.log("Done inserting into!!")
        }
    })
})