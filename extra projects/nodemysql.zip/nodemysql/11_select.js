var mysql = require("mysql")
var con = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database: "mynodedb"
});
con.connect(function(err){
    if(err){
        console.log(err);
        return err;
    }
    console.log("conected!");
    var sql = "select * from  customers LIMIT 4 OFFSET 2  ";
    con.query(sql, function(err, res, fields){
        if(err){
            console.log(err);
            return err;
        }
        else {
            console.log(res);
        }
    })
})