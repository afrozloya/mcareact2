var mysql = require("mysql")
var con = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database: "mynodedb"
});
con.connect(function(err){
    if(err){
        console.log(err);
        return err;
    }
    console.log("conected!");
    var sql = "select users.name as user, products.name as fav from  users join products on users.favorite_product = products.id";
    con.query(sql, function(err, res, fields){
        if(err){
            console.log(err);
            return err;
        }
        else {
            console.log(res);
        }
    })
})