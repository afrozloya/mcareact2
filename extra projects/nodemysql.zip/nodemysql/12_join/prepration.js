var mysql = require("mysql")
var con = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database: "mynodedb"
});
con.connect(function(err){
    if(err){
        console.log(err);
        return err;
    }
    console.log("conected!");
    var sql = "create table users (id int auto_increment primary key, name varchar(255), favorite_product int) ";
    con.query(sql, function(err, res){
        if(err){
            console.log(err);
            return err;
        }
        else {
            console.log("Done creating table!!")
        }
    })

    sql = "create table products (id int auto_increment primary key, name varchar(255)) ";
    con.query(sql, function(err, res){
        if(err){
            console.log(err);
            return err;
        }
        else {
            console.log("Done creating table!!")
        }
    })


    var sql = "insert into products (id, name) values ? ";
    var values = [
        [ 154, 'Chocolate Heaven' ],
        [ 155, 'Tasty Lemons' ],
        [ 156, 'Vanilla Dreams' ]
      ]
    con.query(sql, [values], function(err, res){
        if(err){
            console.log(err);
            return err;
        }
        else {
            console.log("Done inserting into!!")
        }
    })


    var sql = "insert into users (id, name, favorite_product) values ? ";
    var values = [
        [1, 'John', 154],
        [2, 'Peter', 154],
        [3, 'Amy', 155],
        [4, 'Hannah', null],
        [5, 'Michael', null]
      ]
    con.query(sql, [values], function(err, res){
        if(err){
            console.log(err);
            return err;
        }
        else {
            console.log("Done inserting into!!")
        }
    })


})