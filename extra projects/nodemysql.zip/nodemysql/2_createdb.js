var mysql = require("mysql")
var con = mysql.createConnection({
    host: "localhost",
    user:"root",
    password: ""
});
con.connect(function(err){
    if(err){
        return err;
    }
    console.log("connected!!")
    var sql = "create schema if not exists mynodedb"
    con.query(sql, function(err, res){
        if(err){
            console.log(err);
            return err;
        }
        else{
            console.log("Done!!");
        }
    });
})