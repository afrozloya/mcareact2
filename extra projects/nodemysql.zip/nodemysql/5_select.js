var mysql = require("mysql")
var con = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database: "mynodedb"
});
con.connect(function(err){
    if(err){
        console.log(err);
        return err;
    }
    console.log("conected!");
    // var sql = "select * from  customers  ";
    // var sql = "select name from  customers  ";
    var sql = "select * from  customers where name like ? ";   
    con.query(sql, ["s%"], function(err, res, fields){
        if(err){
            console.log(err);
            return err;
        }
        else {
            console.log("-----------------")
            console.log(res);
            console.log("===================")
            console.log(res[0].name)
            console.log("===================")
            // console.log(fields);
        }
    })
})