var mysql = require("mysql")
var con = mysql.createConnection({
    host:"localhost",
    user:"root",
    password:"",
    database: "mynodedb"
});
con.connect(function(err){
    if(err){
        console.log(err);
        return err;
    }
    console.log("conected!");
    // var name = "b' or 'b' = 'b"
    var name = "ajay"
    // name = mysql.escape(name)
    // var sql = `select * from  customers  where name = ${name}`;
    var sql = `select * from  customers  where name = ?`;
    con.query(sql, [name], function(err, res, fields){
        if(err){
            console.log(err);
            return err;
        }
        else {
            console.log(res);
        }
    })
})