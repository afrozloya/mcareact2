var express = require("express");
var bodyParser = require("body-parser");
var movies = require("./movies");
var app = express();
app.use(bodyParser.json());
app.use("/movies", movies);
app.use(bodyParser.urlencoded({extended:true}));
app.listen(3000);
