function getDb(){
    return new Promise((resolve, reject) => {
        var MongoClient = require("mongodb").MongoClient
        var url = "mongodb://localhost:27017/moviesdb"
        MongoClient.connect(url, function(err, db){
        if(err){
            reject(err);
        } else {
            var dbo = db.db("moviesdb");
            resolve(dbo);
        }
      })            
    })    
}
function getMovies(){
    return new Promise((resolve, reject) => {
        getDb().then( dbo => {
            dbo.collection("movies").find({}).toArray(function(err, res){
                if(err){
                    reject(err);
                }
                resolve(res);
            })    
        })
    });
}            
function insertMovie(m1){
    return new Promise((resolve, reject) => {
        getDb().then( dbo => {
            dbo.collection("movies").insertOne(m1, function(err, res){
                if(err){
                    reject(err);
                }
                resolve(res);
            })    
        })
    });
}     

function getMovieById(id){
    return new Promise((resolve, reject) => {
        getDb().then( dbo => {
            var query = {id: +id} 
            dbo.collection("movies").findOne(query, function(err, res){
                if(err){
                    reject(err);
                }
                resolve(res);
            })    
        })
    });
}            

function deleteMovie(id){
    return new Promise((resolve, reject) => {
        getDb().then( dbo => {
            var query = {id: +id} 
            dbo.collection("movies").deleteOne(query, function(err, res){
                if(err){
                    reject(err);
                }
                resolve(res);
            })    
        })
    });
}            

function updateMovie(id, m1){
    return new Promise((resolve, reject) => {
        getDb().then( dbo => {
            var query = {id: +id} 
            m1._id;
            var up = {$set: {...m1}}
            dbo.collection("movies").updateOne(query, up, function(err, res){
                if(err){
                    reject(err);
                }
                resolve(res);
            })    
        })
    });
}            


module.exports = {
    getMovies,
    insertMovie,
    getMovieById,
    deleteMovie,
    updateMovie
}