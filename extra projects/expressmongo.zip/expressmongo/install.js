var MongoClient = require("mongodb").MongoClient
var url = "mongodb://localhost:27017/moviesdb"
MongoClient.connect(url, function(err, db){
    if(err){
        throw err;
    } else {
        var dbo = db.db("moviesdb");
        var data = [
            {id: 101, name: "Fight Club", year: 1999, rating: 8.1},
            {id: 102, name: "Inception", year: 2010, rating: 8.7},
            {id: 103, name: "The Dark Knight", year: 2008, rating: 9},
            {id: 104, name: "12 Angry Men", year: 1957, rating: 8.9}
         ];
         dbo.collection("movies").insertMany(data, function(err, res){
            if(err){
                throw err;
            } else {
                console.log("inserted!");
            }
         })         
        console.log("connected!");
    }
})