import React, { Component } from 'react'
import A from './A'
export default class App5 extends Component {
    render() {
        return (
            <div>
                <h1>Naya....</h1>
                <A/>
            </div>
        )
    }
}
