import React, { Component } from 'react'

export default class Sum extends React.PureComponent {
// export default class Sum extends Component {
        componentDidUpdate(){
        console.log("sum is getting updated.......")
    }
    // shouldComponentUpdate(nextProps, nextState){        
    //     if((nextProps.no1 != this.props.no1) || (nextProps.no2 != this.props.no2) ){
    //         return true;
    //     }
    //     else{
    //         return false;
    //     }
    // }
    render() {
        return (
            <div>
                <h1>Sum is { +this.props.no1 + +this.props.no2}</h1>
            </div>
        )
    }
}
