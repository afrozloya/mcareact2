import React, { Component } from 'react'
import Parent from './Parent'
export default class App4 extends Component {
    render() {
        return (
            <div>
                <h1>Life Cycle Method!</h1>
                <Parent />
            </div>
        )
    }
}
