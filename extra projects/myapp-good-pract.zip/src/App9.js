import React, { Component } from 'react'

export default class App9 extends Component {
    count2 = 0;
    state = {
        count: 0
    }
    onClk = () => {
        for(let i =0;i<10;i++){
            console.log(this.count2++)
            console.log(this.state.count)
            // this.setState({
            //     count: this.state.count+1
            // })    
            this.setState((prevState, prevProps) => {
                return {
                    count: prevState.count+1
                }
            })    
        }
    }
    render() {
        return (
            <div>
                <h1 onClick={this.onClk}>{this.state.count}</h1>
            </div>
        )
    }
}
