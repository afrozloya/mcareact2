import React, { Component } from 'react'

export default class componentName extends Component {
    onClk = (e, name) => {
        console.log(e)
        console.log(name)
    }
    render() {
        return (
            <div>
                <h1>Faltu....</h1>
                <button onClick={this.onClk}>Clk Me</button>
                <button onClick={(e) => this.onClk(e, "abc")}>Clk Me</button>
            </div>
        )
    }
}
