import React, { Component } from 'react'
import MyErr from './MyErr'
import App7 from './App7'
import MyAppBoundry from './MyErrBoundry'
export default class App8 extends Component {
    render() {
        return (
            <MyAppBoundry>
                <MyErr />
                <App7 />
            </MyAppBoundry>
        )
    }
}
