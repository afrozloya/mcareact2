import React, { Component } from 'react'

export default class MyErrBoundry extends Component {
    state = {
        error: null
    }
    static getDerivedStateFromError(error) {
        console.log(error)
        return {
            error: error
        }
    }
    render() {
        return (
            <div>
                {
                    this.state.error 
                    ? <p>Errorwa......:: {this.state.error}</p>
                    : this.props.children
                }
                
            </div>
        )
    }
}
