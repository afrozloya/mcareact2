import React, { Component } from 'react'
// import './ScrollList.css'

export default class ScrollingList extends Component {
    myref = React.createRef()
    state = {
        mylist: [
            1,2,3, 4,5,6,7,8,9,10,
            11,12,13, 14,15,16,17,18,19,20,
            21,22,23, 24,25,26,27,28,29,30,
        ]
    }

    onUp = () => {
        setTimeout(() => {
            const mylistnew = [...this.state.mylist]
            mylistnew.push(31,32,33,34);
            this.setState({
                mylist: mylistnew
            })                
        }, 3000);
    }
    getSnapshotBeforeUpdate(prevProps, prevState){ 
        console.log(this.myref.current.scrollHeight - this.myref.current.scrollTop)
        console.log(this.myref.current.scrollHeight)
        console.log(this.myref.current.scrollTop)
        return this.myref.current.scrollHeight- this.myref.current.scrollTop;       
    }
    componentDidUpdate(prevProps, prevState, snapshot){
        // console.log(this.myref.current.scrollHeight - snapshot)
        // console.log(this.myref.current.scrollHeight)
        this.myref.current.scrollTop = this.myref.current.scrollHeight - snapshot
    }
    render() {
        // if(this.myref.current){
        //     console.log(this.myref.current.scrollHeight - this.myref.current.scrollTop)
        //     console.log(this.myref.current.scrollHeight)
        //     console.log(this.myref.current.scrollTop)    
        // }
        // const st = {
        //     "backgroundColor": "lightblue",
        //     "height": "300px",
        //     "overflow": "scroll"
        // }
        return (
            <div style={{ backgroundColor: 'pink',
            "height": "300px",
            "overflow": "scroll"}} ref={this.myref}>
                <h1>I am sc list</h1>
                <button onClick={this.onUp}>Update</button>
                {
                    this.state.mylist.map( e => <h1 key={e}>{e}</h1>)
                }
            </div>
        )
    }
}
