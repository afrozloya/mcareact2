import React, { Component } from 'react'
import FancyText from './FancyText'

export default class App14 extends Component {
    render() {
        return (
            <div>
                <FancyText>
                    Abcd
                </FancyText>
            </div>
        )
    }
}
