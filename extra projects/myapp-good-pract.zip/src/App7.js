import React, { Component } from 'react'
import axios from 'axios'

export default class App7 extends Component {
    state = {
        type: 'todos',
        data: []
    }
    onChangeHand = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    }
    componentDidUpdate(prevProps, prevState, snapshot){
        console.log("componentDidUpdate");
        if(prevState.type !== this.state.type){
            const url = `https://jsonplaceholder.typicode.com/${this.state.type}`;
            axios.get(url)
            .then(resp => {
                this.setState({
                    data: resp.data
                })
            })
            .catch(err => {
                console.log(err)
            })    
        }
    }
    render() {
        return (
            <div>
                <h1>App7..... {this.state.type}</h1>
                <select name="type" value={this.state.type} onChange={this.onChangeHand}>
                <option value="todos">Todo</option>                    
                <option value="posts">Post</option>                    
                </select>
                {
                    this.state.data.map(t1 => <p>{t1.title}</p>)
                }
            </div>
        )
    }
}
