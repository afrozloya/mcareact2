import React, { Component } from 'react'
import TempInput from './TempInput'
import Boiling from './Boiling'

export default class App13 extends Component {
    state = {
        temp: 0,
    }
    onChangeHand = (e) => {
        this.setState({
            [e.target.name]: e.target.value
        })
    } 
    render() {
        return (
            <div>
                <TempInput temp={this.state.temp} myOnChange={this.onChangeHand} />
                <Boiling temp={this.state.temp} />
            </div>
        )
    }
}
