import React, { Component } from 'react'

export default class CounterShow extends Component {
    state = {
        incBy: 1,
      }    
    render() {
        return (
            <div>
        <input name="incBy" value={this.state.incBy} onChange={(e)=>{this.setState({[e.target.name]: +e.target.value})}} type="number" />
        <button onClick={()=>this.incr()}>Incr</button>
        <button onClick={()=>this.decr()}>Decr</button>
                
            </div>
        )
    }
}
