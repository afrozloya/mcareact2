import * as actionTypes from './actionTypes'

export const incr = () => {
    return {
        type: actionTypes.INCR,
        by: 1
    }
}

export const decr = () => {
    return {
        type: actionTypes.DECR,
        by: 1
    }
}