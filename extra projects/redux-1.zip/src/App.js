import React, { Component } from 'react'
import {connect} from 'react-redux'
import {incr} from './store/actions/actions'
// import Counter from './Counter';
// import CounterShow from './CounterShow';


class App extends Component {
  render() {
    return (
      <div>
        <h1>hi all!!</h1>
        <h1>{ this.props.no }</h1>
        <button onClick={()=>this.props.incr()}>incr</button>
        {/* <Counter />
        <CounterShow /> */}
      </div>
    );  
  }
}
const mapStateToProps = (state) => {
  return {
    no: state.no,
  }
}
const mapDispatchToProps = (dispatch) => {
  return {
    incr: () => {dispatch(incr())}
  }
}
export default connect(mapStateToProps, mapDispatchToProps)(App)