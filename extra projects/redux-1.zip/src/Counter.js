import React, { Component } from 'react'

export default class Counter extends Component {
    
    state = {
        no:0,
    }
    
    incr = () => {
        this.setState({
          no: this.state.no + this.props.incBy
        })
    }
      decr = () => {
        this.setState({
          no: this.state.no - this.props.incBy
        })
    }
    render() {
        return (
            <div>
                <h1>Current Count is ....{this.props.Inc}</h1>
            </div>
        )
    }
}
