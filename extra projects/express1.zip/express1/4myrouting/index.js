var express = require("express");
var app = express();
var loginroutes = require("./loginroutes");
app.use("/account", loginroutes);
var server = app.listen(8080);
