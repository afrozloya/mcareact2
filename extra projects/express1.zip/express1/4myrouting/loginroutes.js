var express = require("express");
var router = express.Router()
router.get("/login", function(req, res){
    res.send("<h1>Login....</h1>");
})
router.get("/signup", function(req, res){
    res.send("<h1>Signup....</h1>");
})
module.exports = router;
