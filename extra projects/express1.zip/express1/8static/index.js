var express = require("express");
var app = express();
app.use(express.static('8static/public'))
app.set('view engine', 'pug');
app.set('views','./8static/views');
app.get("/", function(req, res){
    res.render("first");
})
var server = app.listen(3000);