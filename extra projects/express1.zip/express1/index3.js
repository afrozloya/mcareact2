var express = require("express");
var app = express();
app.get("/hello", function(req, res){
    res.send("<h1>GEt and hello....</h1>");
})
app.post("/hello", function(req, res){
    res.send("<h1>Post for hello....</h1>");
})
app.all("/kake", function(req, res){
    res.send("<h1>Get / Post / All for kake....</h1>");
})

var server = app.listen(8080);
