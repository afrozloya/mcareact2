var express = require("express");
var app = express();
app.set('view engine', 'pug');
app.set('views','./7pug/views');
app.get("/", function(req, res){
    res.render("first_view", {msg:"Samjhe Kya....."});
})
var server = app.listen(3000);