var express = require("express");
var app = express();
app.use("/secure", function(req, res, next){
    res.write("<h1>Login check.......</h1>")
    next();
})
app.get("/secure/home", function(req, res){
    res.write("<h1>Samjhe Kya!!</h1>");
})
app.get("/about", function(req, res){
    res.write("<h1>About us......!!</h1>");
})
app.route("/secure/contact").get(function(req, res){
    res.write("<h1>Contact us......!!</h1>");
})

var server = app.listen(3000);