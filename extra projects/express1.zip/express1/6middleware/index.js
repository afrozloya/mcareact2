var express = require("express");
var app = express();
app.use(function(req, res, next){
    res.write("<h1>Pre Proc.......</h1>")
    if(req.url==='/about'){
        res.write("<h1>Login required.......</h1>")
    } else {
        next();
    }
    res.end("<h1>Post Porc.......</h1>")
})
app.get("/", function(req, res){
    res.write("<h1>Samjhe Kya!!</h1>");
})
app.get("/about", function(req, res){
    res.write("<h1>About us......!!</h1>");
})
app.route("/contact").get(function(req, res){
    res.write("<h1>Contact us......!!</h1>");
})

var server = app.listen(3000);