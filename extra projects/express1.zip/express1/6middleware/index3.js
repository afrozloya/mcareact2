var express = require("express");
var app = express();
app.use(function(req, res, next){
    res.write("<h1>Pratham....</h1>")
    next();
})
app.use(function(req, res, next){
    res.write("<h1>Madhya....</h1>")
    next();
})
app.use(function(req, res, next){
    res.write("<h1>Ant....</h1>")
    next();
})
app.get("/", function(req, res){
    res.write("<h1>Bla Bla......!!</h1>");
})
var server = app.listen(3000);