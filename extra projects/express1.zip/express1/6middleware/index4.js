var express = require("express")
var bodyparser = require("body-parser")
var app = express()
app.use(bodyparser.urlencoded({extended:false}))
app.use(bodyparser.json())
app.post('/', function(req, res){
    console.log(req.body);
    res.send("Bla Bla");
 });
 var server = app.listen(8081)
