var express = require("express")
var app = express()
app.set("view engine","jade")
app.get("/", function(req, res){
    res.render("index", {title:"Home", message:"samjhe ki nahi...."} )
})
// app.get("/about", function(req, res){
//     res.render("index", {title:"Home", message:"we started.........."} )
// })

var server = app.listen(3000)